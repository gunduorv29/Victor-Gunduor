# Victor Gunduor, portfolio

A static, crawlable one-page portfolio. HTML plus Tailwind CSS 3 (compiled and inlined into the page), self-hosted Anton and Manrope fonts, inline SVG icons. No CDN, no client-side framework, nothing rendered by JavaScript. The page reads fine with JavaScript off.

Everything you may need to change lives in `site.config.json`. Anything left empty is hidden, never faked.

## Commands

```bash
npm install            # once
npm run build          # src/ + site.config.json -> dist/
npm run check          # static checks on dist/ (markup, copy rules, links, SEO)
npm run test:browser   # Playwright + axe: layout, accessibility, theme, menu, motion, no-JS, contact form
npm test               # build, then check, then test:browser
npm run og             # redraw src/og-image.png (1200x630) from the portrait and hero lines
```

`npm run build` prints warnings for anything still missing (no domain, no contact route, unset links). `claims-report.txt` is written next to `package.json` (never into `dist/`) and lists every sentence only you can vouch for.

## Configure: `site.config.json`

| Key | What it does | If empty |
| --- | --- | --- |
| `siteUrl` | Your real production address, for example `https://yourname.dev`. | No canonical link, no Open Graph image, no `WebSite` data, no `sitemap.xml`. |
| `email` | Public contact address. | See contact modes below. |
| `formEndpoint` | A form service URL (`https://...`) that accepts a POST. | See contact modes below. |
| `formHiddenFields` | Extra hidden inputs the service needs, as `{ "name": "value" }`. | Nothing added. |
| `analytics.plausibleDomain` | Your domain as registered in Plausible. | No analytics code at all. |
| `links.*` | Every profile and project URL. | The button or line that uses it disappears. |

Everything in this file ends up in public HTML. Never put a secret in it.

Environment variables override the file, which is handy in CI: `SITE_URL`, `CONTACT_EMAIL`, `FORM_ENDPOINT`, `PLAUSIBLE_DOMAIN`. `OUT_DIR` changes the output folder and `SITE_CONFIG` points at a different config file; the tests use both.

### Contact modes

- **Endpoint** (`formEndpoint` set): the form posts with `fetch`, asking for JSON. The page says "Message sent" only when the response is OK and the JSON does not say `success: false` or `ok: false`. On any failure it says the message was not sent, keeps what the visitor typed and offers `email` if you set one. Without JavaScript the form falls back to a normal POST.
- **Email** (`email` set, no endpoint): the button reads "Open in my email app", opens the visitor's mail program with the message filled in, and says nothing has been sent until they press send. Some mail programs cut very long messages. Without JavaScript the form is hidden and the address is shown instead.
- **None**: the section says "Contact details are not published yet." No form is drawn.

A honeypot field (`_gotcha`) is on every form. With JavaScript on, a submission that fills it is dropped silently.

## Edit the page

`src/index.html` is a template. The build understands:

- `{{key}}` prints a config value, HTML-escaped. `{{@year}}`, `{{@jsonld}}` and `{{@formHidden}}` are generated.
- `<!--#if a|!b-->...<!--#else-->...<!--#endif-->` shows a block when `a` is set or `b` is not. An unknown key stops the build.
- `data-claim="id"` marks a sentence that comes from you alone. The build removes the attribute and lists the sentence in `claims-report.txt`. When you have confirmed a sentence, delete the attribute. If it is not true, change the sentence.

Colours and fonts are in `src/input.css` and `tailwind.config.js`. Light and dark themes are RGB-channel variables in `:root` and `.dark`.

## Deploy

`dist/` is plain static files. Upload its contents to any static host, or let the host build it:

- Build command: `npm install && npm run build`
- Publish directory: `dist`

Set `siteUrl` first (or `SITE_URL` in the host's settings) so the canonical link, social card and sitemap are produced. `dist/` and `claims-report.txt` are in `.gitignore`.

## What the checks enforce

The static checks fail the build pipeline when the output contains: a contraction, any removed or invented claim (the old stats, Kraken Orderbook, unsupported tools, performance scores), an email other than the configured one, a placeholder or dead link, a missing file, a skipped heading level, duplicate ids, a missing alt text, an external stylesheet or CDN, or SEO tags that name a domain you never set. The browser tests also prove the contact form never shows a success message unless the server accepted the message.

## Layout

```
src/index.html        the page (template)
src/input.css         Tailwind entry, theme variables, components
src/fonts, images     self-hosted fonts and the portrait (480 and 800 px, jpg and webp)
src/favicon.svg       VG monogram
src/og-image.png      social card, made by npm run og
site.config.json      the only file you normally edit
scripts/              build, check, browser-check, make-og, config
dist/                 the site, ready to upload
screenshots/          full-page captures from the test run
```
