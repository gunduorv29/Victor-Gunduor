// Builds dist/ from src/ and site.config.json. No framework, no runtime dependencies.
//
//   <!--#if a|!b-->...<!--#else-->...<!--#endif-->   conditional (| is OR, ! is NOT, innermost first)
//   {{key}}                                          HTML-escaped value from the config
//   {{@year}} {{@jsonld}} {{@formHidden}}            generated values
//   <!--@css-->                                      the compiled Tailwind stylesheet, inlined
//   data-claim="id"                                  marks a statement that only Victor can vouch for;
//                                                    the attribute is stripped and listed in claims-report.txt
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { ROOT, loadConfig, buildValues } from './config.mjs';

const SRC = path.join(ROOT, 'src');
const DIST = process.env.OUT_DIR ? path.resolve(process.env.OUT_DIR) : path.join(ROOT, 'dist');
const CACHE = path.join(ROOT, '.build-cache');
const IS_TEST_BUILD = Boolean(process.env.OUT_DIR);

const esc = (s) =>
  String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const decodeEntities = (s) =>
  s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&copy;/g, '©')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');

function evalExpr(expr, values) {
  return expr.split('|').some((term) => {
    let t = term.trim();
    let negate = false;
    if (t.startsWith('!')) {
      negate = true;
      t = t.slice(1).trim();
    }
    if (!(t in values)) throw new Error(`Unknown condition key "${t}" in <!--#if ${expr}-->`);
    const truthy = Boolean(values[t]);
    return negate ? !truthy : truthy;
  });
}

function applyConditionals(html, values) {
  const innermost = /<!--#if ([^>]*?)-->((?:(?!<!--#if )[\s\S])*?)<!--#endif-->/;
  let guard = 0;
  while (innermost.test(html)) {
    if (++guard > 2000) throw new Error('Too many conditional blocks.');
    html = html.replace(innermost, (_m, expr, body) => {
      const parts = body.split('<!--#else-->');
      if (parts.length > 2) throw new Error(`More than one #else in block "${expr}".`);
      return evalExpr(expr, values) ? parts[0] : parts[1] || '';
    });
  }
  if (/<!--#(if|else|endif)/.test(html)) throw new Error('Unbalanced conditional markers in a template.');
  return html;
}

function applyTokens(html, values, specials) {
  return html.replace(/\{\{\s*([@A-Za-z0-9_.]+)\s*\}\}/g, (_m, key) => {
    if (key.startsWith('@')) {
      if (!(key in specials)) throw new Error(`Unknown special token {{${key}}}.`);
      return specials[key];
    }
    if (!(key in values)) throw new Error(`Unknown token {{${key}}}.`);
    return esc(values[key]);
  });
}

function buildJsonLd(c) {
  const L = c.links;
  const personId = c.siteUrl ? `${c.siteUrl}/#person` : undefined;
  const person = {
    '@type': 'Person',
    '@id': personId,
    name: 'Victor Gunduor',
    alternateName: 'Lord Gundu',
    jobTitle: 'Frontend developer',
    description: 'Frontend developer in Lagos, Nigeria, building React and Next.js products on Supabase and Solana.',
    url: c.siteUrl ? `${c.siteUrl}/` : undefined,
    image: c.siteUrl ? `${c.siteUrl}/images/victor-gunduor-800.jpg` : undefined,
    email: c.email || undefined,
    address: { '@type': 'PostalAddress', addressLocality: 'Lagos', addressCountry: 'NG' },
    knowsAbout: ['Frontend development', 'React', 'Next.js', 'Supabase', 'Solana', 'Technical writing'],
    sameAs: [L.github, L.x, L.linkedin, L.medium].filter(Boolean),
    worksFor: L.ghonsiProof ? { '@type': 'Organization', name: 'Ghonsi Proof', url: L.ghonsiProof } : undefined,
  };
  const graph = [person];
  if (c.siteUrl) {
    graph.push({
      '@type': 'WebSite',
      '@id': `${c.siteUrl}/#website`,
      name: 'Victor Gunduor',
      url: `${c.siteUrl}/`,
      inLanguage: 'en',
      publisher: { '@id': personId },
    });
  }
  // "<" is escaped so the data can never close its own <script> tag.
  return JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }).replace(/</g, '\\u003c');
}

function buildFormHidden(hidden) {
  return Object.entries(hidden)
    .map(([k, v]) => `<input type="hidden" name="${esc(k)}" value="${esc(v)}">`)
    .join('\n        ');
}

function buildCss() {
  fs.mkdirSync(CACHE, { recursive: true });
  const out = path.join(CACHE, 'tailwind.css');
  const bin = path.join(ROOT, 'node_modules', '.bin', 'tailwindcss');
  execFileSync(bin, ['-c', 'tailwind.config.js', '-i', 'src/input.css', '-o', out, '--minify'], {
    cwd: ROOT,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  return fs.readFileSync(out, 'utf8').trim();
}

// Records every data-claim statement (id and the first 150 characters of its text), then strips the attribute.
function collectClaims(html, page, sink) {
  const open = /<([a-z][a-z0-9]*)\b[^>]*?\sdata-claim="([^"]+)"[^>]*>/gi;
  let m;
  while ((m = open.exec(html))) {
    const tag = m[1].toLowerCase();
    const bounds = new RegExp(`<${tag}\\b|</${tag}\\s*>`, 'gi');
    bounds.lastIndex = open.lastIndex;
    let depth = 1;
    let end = html.length;
    let b;
    while ((b = bounds.exec(html))) {
      if (b[0][1] === '/') {
        depth -= 1;
        if (depth === 0) {
          end = b.index;
          break;
        }
      } else {
        depth += 1;
      }
    }
    const text = decodeEntities(html.slice(open.lastIndex, end).replace(/<[^>]*>/g, ' '))
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 150);
    sink.push({ page, id: m[2], text });
  }
  return html.replace(/ data-claim="[^"]+"/g, '');
}

function main() {
  const cfg = loadConfig();
  const values = buildValues(cfg);
  const errors = [...cfg.errors];
  const warnings = [];
  const notes = [];

  const css = buildCss();
  fs.rmSync(DIST, { recursive: true, force: true });
  fs.mkdirSync(DIST, { recursive: true });

  const specials = {
    '@year': String(new Date().getFullYear()),
    '@jsonld': buildJsonLd(cfg),
    '@formHidden': buildFormHidden(cfg.hidden),
  };

  const pages = fs.readdirSync(SRC).filter((f) => f.endsWith('.html'));
  const claims = [];
  const sizes = {};
  for (const file of pages) {
    let html = fs.readFileSync(path.join(SRC, file), 'utf8');
    html = applyConditionals(html, values);
    html = html.replace('<!--@css-->', () => `<style>${css}</style>`);
    html = applyTokens(html, values, specials);
    html = html.replace(/<!--(?!\[if)[\s\S]*?-->/g, '');
    html = collectClaims(html, file, claims);
    html = html.replace(/\n[ \t]*\n(?:[ \t]*\n)+/g, '\n\n');
    if (/\{\{|<!--#/.test(html)) throw new Error(`${file}: unresolved template markers remain.`);
    fs.writeFileSync(path.join(DIST, file), html);
    sizes[file] = Buffer.byteLength(html);
  }

  for (const dir of ['fonts', 'images']) {
    if (fs.existsSync(path.join(SRC, dir))) fs.cpSync(path.join(SRC, dir), path.join(DIST, dir), { recursive: true });
  }
  for (const file of ['favicon.svg', 'og-image.png']) {
    if (fs.existsSync(path.join(SRC, file))) fs.copyFileSync(path.join(SRC, file), path.join(DIST, file));
  }
  if (!fs.existsSync(path.join(SRC, 'og-image.png'))) warnings.push('src/og-image.png is missing. Run "npm run og".');

  // robots.txt always; sitemap.xml only when the real address is known.
  let robots = 'User-agent: *\nAllow: /\n';
  if (cfg.siteUrl) {
    robots += `Sitemap: ${cfg.siteUrl}/sitemap.xml\n`;
    fs.writeFileSync(
      path.join(DIST, 'sitemap.xml'),
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${cfg.siteUrl}/</loc></url>\n</urlset>\n`,
    );
  }
  fs.writeFileSync(path.join(DIST, 'robots.txt'), robots);

  // The list of statements to confirm stays out of dist/, and out of test builds.
  const unique = [...new Map(claims.map((c) => [c.id, c])).values()];
  if (!IS_TEST_BUILD) {
    const header =
      'Statements on the page that come from Victor and have no public source yet.\n' +
      'Confirm each one, or delete the line, before publishing.\n\n';
    fs.writeFileSync(
      path.join(ROOT, 'claims-report.txt'),
      header + unique.map((c) => `${c.id.padEnd(18)} ${c.text}`).join('\n') + '\n',
    );
  }

  if (!cfg.siteUrl) {
    warnings.push(
      'siteUrl is empty. The canonical link, social image and sitemap are left out until you set it (site.config.json or SITE_URL).',
    );
  }
  if (!cfg.email && !cfg.formEndpoint) {
    warnings.push('No email and no formEndpoint. The contact section says "Contact details are not published yet."');
  }
  if (!cfg.formEndpoint && cfg.email) {
    notes.push('The contact form is in email mode: it opens the visitor\'s email app. Set formEndpoint to receive messages directly.');
  }
  if (!cfg.plausibleDomain) notes.push('Analytics are off (no plausibleDomain).');
  const unset = Object.entries(cfg.links)
    .filter(([, v]) => !v)
    .map(([k]) => k);
  if (unset.length) notes.push(`Links not set, so their buttons are hidden: ${unset.join(', ')}.`);

  const rel = path.relative(ROOT, DIST) || '.';
  console.log(`Built ${pages.length} page${pages.length === 1 ? '' : 's'} into ${rel}/`);
  for (const [file, bytes] of Object.entries(sizes)) {
    console.log(`  ${file} ${(bytes / 1024).toFixed(1)} KB (CSS inlined: ${(Buffer.byteLength(css) / 1024).toFixed(1)} KB)`);
  }
  if (!IS_TEST_BUILD) {
    console.log(`  ${unique.length} statements from your own account are marked (see claims-report.txt)`);
  }
  for (const w of warnings) console.log(`WARNING: ${w}`);
  for (const n of notes) console.log(`note: ${n}`);
  for (const e of errors) console.log(`ERROR: ${e}`);
  if (errors.length) process.exit(1);
}

try {
  main();
} catch (err) {
  const detail = err && err.stderr && String(err.stderr).trim() ? String(err.stderr).trim() : err.message;
  console.error(`Build failed: ${detail}`);
  process.exit(1);
}
