// Renders src/og-image.png (1200x630) from the portrait and the three hero lines.
// Uses the same fonts as the site. Run: npm run og
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { ROOT } from './config.mjs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const SRC = path.join(ROOT, 'src');
const CACHE = path.join(ROOT, '.build-cache');
fs.mkdirSync(CACHE, { recursive: true });

const anton = pathToFileURL(path.join(SRC, 'fonts', 'anton-latin-400-normal.woff2')).href;
const manrope = pathToFileURL(path.join(SRC, 'fonts', 'manrope-latin-wght-normal.woff2')).href;
const photo = pathToFileURL(path.join(SRC, 'images', 'victor-gunduor-800.jpg')).href;

const html = `<!doctype html>
<html><head><meta charset="utf-8"><style>
@font-face{font-family:Anton;src:url(${anton}) format('woff2');font-weight:400}
@font-face{font-family:Manrope;src:url(${manrope}) format('woff2');font-weight:200 800}
html,body{margin:0;width:1200px;height:630px;background:#18181b;overflow:hidden}
.frame{position:absolute;inset:28px;border:2px solid #71717a}
.name{position:absolute;left:78px;top:104px;font:400 100px/1 Anton,Impact,sans-serif;letter-spacing:.01em;text-transform:uppercase;color:#fafafa;white-space:nowrap}
.role{position:absolute;left:80px;top:232px;font:800 40px/1.2 Manrope,sans-serif;color:#c6a87c;white-space:nowrap}
.lines{position:absolute;left:80px;top:326px;font:500 32px/1.45 Manrope,sans-serif;color:#d4d4d8}
.lines span{display:block}
.ph{position:absolute;right:92px;top:112px;width:360px;height:360px}
.ph::before{content:'';position:absolute;inset:0;transform:translate(16px,16px);background:#c6a87c;border:2px solid #fafafa}
.ph img{position:relative;display:block;width:360px;height:360px;object-fit:cover;object-position:50% 30%;border:2px solid #fafafa;box-sizing:border-box}
</style></head><body>
<div class="frame"></div>
<div class="name">Victor Gunduor</div>
<div class="role">Frontend developer in Lagos</div>
<div class="lines"><span>Engineering digital products.</span><span>Communicating ideas.</span><span>Solving real problems.</span></div>
<div class="ph"><img src="${photo}" alt=""></div>
</body></html>`;

// Written to disk and opened with file:// so the fonts and the photo can load.
const htmlPath = path.join(CACHE, 'og.html');
fs.writeFileSync(htmlPath, html);

const browser = await chromium.launch();
try {
  const page = await browser.newPage({ viewport: { width: 1200, height: 630 }, deviceScaleFactor: 1 });
  await page.goto(pathToFileURL(htmlPath).href, { waitUntil: 'load' });
  const ready = await page.evaluate(async () => {
    await Promise.all([document.fonts.load('100px Anton'), document.fonts.load('800 40px Manrope')]);
    await document.fonts.ready;
    return {
      anton: document.fonts.check('40px Anton'),
      manrope: document.fonts.check('800 40px Manrope'),
      images: [...document.images].every((i) => i.complete && i.naturalWidth > 0),
    };
  });
  if (!ready.anton || !ready.manrope || !ready.images) {
    console.error('The fonts or the photo did not load:', JSON.stringify(ready));
    process.exitCode = 1;
  } else {
    const out = path.join(SRC, 'og-image.png');
    await page.screenshot({ path: out, clip: { x: 0, y: 0, width: 1200, height: 630 } });
    console.log(`Wrote src/og-image.png (${(fs.statSync(out).size / 1024).toFixed(0)} KB)`);
  }
} finally {
  await browser.close();
}
