// Static checks on the built page. Exits 1 if anything fails.
// CHECK_DIR picks the folder (default dist). Config and env overrides are read the way the build reads them.
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, loadConfig } from './config.mjs';

const DIR = process.env.CHECK_DIR ? path.resolve(process.env.CHECK_DIR) : path.join(ROOT, 'dist');
const cfg = loadConfig();
const L = cfg.links;

let passed = 0;
let failed = 0;
function check(name, ok, detail = '') {
  if (ok) {
    passed += 1;
    console.log(`PASS  ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL  ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}
function note(message) {
  console.log(`note  ${message}`);
}
const exists = (rel) => fs.existsSync(path.join(DIR, rel));
const decode = (s) =>
  s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&copy;/g, '©')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
const without = (s, tags) =>
  tags.reduce((acc, t) => acc.replace(new RegExp(`<${t}\\b[\\s\\S]*?</${t}>`, 'gi'), ' '), s);

for (const e of cfg.errors) check(`config: ${e}`, false);

const indexPath = path.join(DIR, 'index.html');
if (!fs.existsSync(indexPath)) {
  console.log(`FAIL  ${indexPath} does not exist. Run "npm run build" first.`);
  process.exit(1);
}
const html = fs.readFileSync(indexPath, 'utf8');
const count = (re) => (html.match(re) || []).length;

const markup = without(html, ['script', 'style']);
const visible = decode(markup.replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
const attrText = [...markup.matchAll(/\s(?:alt|content|aria-label|title)="([^"]*)"/g)].map((m) => decode(m[1])).join(' ');
const hrefs = [...markup.matchAll(/\shref="([^"]*)"/g)].map((m) => decode(m[1]));
const ldMatch = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
const ldText = ldMatch ? ldMatch[1] : '';
const copy = `${visible} ${attrText}`;

// ---------------------------------------------------------------- build hygiene
check('no template markers left in the output', !/\{\{|<!--#/.test(html));
check('no data-claim attributes in the output', !/data-claim/.test(html));
check('no HTML comments in the output', !/<!--/.test(html));
check('html has lang="en"', /<html[^>]*\slang="en"/.test(html));
check('viewport meta tag is present', /<meta name="viewport" content="width=device-width, initial-scale=1">/.test(html));
check('favicon is linked and exists', /<link rel="icon" href="favicon\.svg"/.test(html) && exists('favicon.svg'));
check(
  'no private files in the output folder',
  !['claims-report.txt', 'site.config.json', 'HANDOFF.md', 'README.md', '.env'].some(exists),
);

// ---------------------------------------------------------------- copy rules
const CONTRACTION = /\b(?:i|you|we|they|he|she|it|that|there|here|what|who|let|how|where)['’](?:m|re|ve|ll|d|s)\b|\b\w+n['’]t\b/gi;
const contractions = [...new Set(copy.match(CONTRACTION) || [])];
check('copy has no contractions ("I am", not "I\'m")', contractions.length === 0, contractions.join(', '));

const FORBIDDEN = [
  /kraken/i, /order\s*book/i, /\$2M/i, /10M\+/i, /99\.9/, /\b(?:300|40|90|60)%/, /50K\+/i, /1000\+/,
  /\bMVPs?\b/, /uptime/i, /lighthouse/i, /pagespeed/i, /\b\d{2,3}\/100\b/,
  /walletconnect/i, /solidity/i, /ethers\.js/i, /metamask/i, /\bthe graph\b/i, /figma/i, /semrush/i, /ahrefs/i,
  /\baws\b/i, /\bazure\b/i, /\bdocker\b/i, /\bpython\b/i, /mongodb/i,
  /marquee/i, /profile img/i, /stackweck studio/i, /lead frontend architect/i, /founder & lead/i,
  /passionate/i, /cutting-edge/i, /seamless/i, /leverag/i, /world-class/i, /innovative/i, /\brobust\b/i,
  /\bProsper\b/, /\bIsaiah\b/, /\bProdigy\b/, /\bAyere\b/, /\bAdakonye\b/,
  /pinata/i, /\bJWT\b/, /api key/i, /secret/i,
  /lorem ipsum/i, /\bTODO\b/, /\bFIXME\b/, /example\.com/i, /your-email/i, /★/,
];
const scan = `${copy} ${ldText} ${hrefs.join(' ')}`;
const hits = FORBIDDEN.filter((re) => re.test(scan)).map((re) => String(re));
check('copy has none of the removed or forbidden terms', hits.length === 0, hits.join('  '));

const dataEmails = [...markup.matchAll(/data-email="([^"]*)"/g)].map((m) => m[1]).join(' ');
const emailRe = /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+/g;
const foundEmails = [...new Set((`${copy} ${hrefs.join(' ')} ${ldText} ${dataEmails}`.match(emailRe) || []).map((e) => e.toLowerCase()))];
const allowedEmails = cfg.email ? [cfg.email.toLowerCase()] : [];
check(
  cfg.email ? 'only the configured email address appears' : 'no email address appears (none is configured)',
  foundEmails.every((e) => allowedEmails.includes(e)),
  `found: ${foundEmails.join(', ')}`,
);

// ---------------------------------------------------------------- structure
check('exactly one h1', count(/<h1\b/g) === 1);
const levels = [...html.matchAll(/<h([1-6])\b/g)].map((m) => Number(m[1]));
let skipped = '';
levels.reduce((prev, cur, i) => {
  if (cur > prev + 1 && !skipped) skipped = `h${prev} then h${cur} (heading ${i + 1})`;
  return cur;
}, 0);
check('heading levels never skip', !skipped, skipped);
check('one main, one footer, at least one header', count(/<main\b/g) === 1 && count(/<footer\b/g) === 1 && count(/<header\b/g) >= 1);
check('skip link points at the main landmark', /href="#main"/.test(html) && /<main id="main"/.test(html));

const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
const dupes = [...new Set(ids.filter((id, i) => ids.indexOf(id) !== i))];
check('ids are unique', dupes.length === 0, dupes.join(', '));
const idSet = new Set(ids);
const refs = [];
for (const m of html.matchAll(/\s(aria-labelledby|aria-describedby|aria-controls)="([^"]+)"/g)) {
  for (const id of m[2].split(/\s+/)) refs.push([m[1], id]);
}
for (const m of html.matchAll(/<label\b[^>]*\sfor="([^"]+)"/g)) refs.push(['for', m[1]]);
const brokenRefs = refs.filter(([, id]) => !idSet.has(id));
check('aria and label references all resolve', brokenRefs.length === 0, brokenRefs.map(([a, id]) => `${a}="${id}"`).join(', '));

const imgs = [...html.matchAll(/<img\b[^>]*>/g)].map((m) => m[0]);
check(
  'every image has alt, width and height',
  imgs.length > 0 && imgs.every((t) => /\salt="/.test(t) && /\swidth="\d+"/.test(t) && /\sheight="\d+"/.test(t)),
);

// ---------------------------------------------------------------- links and assets
check('no empty or "#" links', !/\shref="(?:#|)"/.test(html));
const deadAnchors = hrefs.filter((h) => h.startsWith('#') && h.length > 1 && !idSet.has(h.slice(1)));
check('every in-page link points at a real id', deadAnchors.length === 0, deadAnchors.join(', '));

const localRefs = new Set();
const addLocal = (u) => {
  if (!u || /^(?:[a-z][a-z0-9+.-]*:|#|\/\/)/i.test(u)) return;
  localRefs.add(u.split(/[?#]/)[0]);
};
for (const m of html.matchAll(/\s(?:src|href)="([^"]*)"/g)) addLocal(decode(m[1]));
for (const m of html.matchAll(/\ssrcset="([^"]*)"/g)) for (const part of m[1].split(',')) addLocal(part.trim().split(/\s+/)[0]);
for (const m of html.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/g)) addLocal(m[1]);
const missing = [...localRefs].filter((p) => !fs.existsSync(path.join(DIR, p)));
check('every local file the page uses exists', missing.length === 0, missing.join(', '));

const mailtos = hrefs.filter((h) => h.startsWith('mailto:'));
check('mailto links are well formed', mailtos.every((h) => /^mailto:[^\s@?]+@[^\s@?]+\.[^\s@?]{2,}$/.test(h)));
const externals = hrefs.filter((h) => /^https?:\/\//i.test(h));
check('external links use https', externals.every((h) => h.startsWith('https://')));
check('no placeholder links', externals.every((h) => !/example\.|your-|yourname|xxx|lorem/i.test(h)));
const anchorTags = [...markup.matchAll(/<a\b[^>]*>/g)].map((m) => m[0]);
const noRel = anchorTags.filter((t) => /\shref="https?:\/\//.test(t) && !/\srel="[^"]*noopener/.test(t));
check('external links carry rel="noopener"', noRel.length === 0, `${noRel.length} without`);

const scriptSrcs = [...html.matchAll(/<script\b[^>]*\ssrc="([^"]*)"/g)].map((m) => m[1]);
check('the only outside script allowed is plausible.io', scriptSrcs.every((s) => s.startsWith('https://plausible.io/')), scriptSrcs.join(', '));
check(
  'no stylesheet links, @import, Google Fonts or CDN builds',
  !/<link\b[^>]*rel="stylesheet"/.test(html) && !/@import/.test(html) && !/googleapis|cdn\.tailwindcss|unpkg/i.test(html),
);
note(`external hosts linked: ${[...new Set(externals.map((h) => new URL(h).host))].join(', ') || 'none'}`);

// ---------------------------------------------------------------- SEO
const metaContent = (attr, key) => {
  const m = html.match(new RegExp(`<meta\\s+${attr}="${key}"\\s+content="([^"]*)"`));
  return m ? decode(m[1]) : '';
};
const title = decode((html.match(/<title>([^<]*)<\/title>/) || [])[1] || '');
check(`title is 20 to 65 characters (${title.length})`, title.length >= 20 && title.length <= 65, title);
const description = metaContent('name', 'description');
check(`meta description is 70 to 160 characters (${description.length})`, description.length >= 70 && description.length <= 160, description);
check(
  'Open Graph basics are present',
  ['og:type', 'og:site_name', 'og:title', 'og:description'].every((k) => metaContent('property', k)),
);
check('Twitter title and description are present', ['twitter:title', 'twitter:description'].every((k) => metaContent('name', k)));
check('robots meta allows indexing', /index, follow/.test(metaContent('name', 'robots')));

let graph = [];
let jsonOk = false;
try {
  const data = JSON.parse(ldText);
  graph = data['@graph'] || [];
  jsonOk = true;
} catch {
  jsonOk = false;
}
check('JSON-LD parses', jsonOk);
const person = graph.find((n) => n['@type'] === 'Person') || {};
check(
  'JSON-LD has a Person with name, job title and a Lagos address',
  person.name === 'Victor Gunduor' && Boolean(person.jobTitle) && person.address && person.address.addressLocality === 'Lagos',
);
const allowedSame = [L.github, L.x, L.linkedin, L.medium].filter(Boolean);
const sameAs = person.sameAs || [];
check(
  'sameAs lists exactly the profile links that are configured',
  sameAs.length === allowedSame.length && sameAs.every((u) => allowedSame.includes(u)),
  JSON.stringify(sameAs),
);
check('JSON-LD email is the configured email or absent', person.email === undefined ? true : person.email === cfg.email);

const robots = exists('robots.txt') ? fs.readFileSync(path.join(DIR, 'robots.txt'), 'utf8') : '';
check('robots.txt allows crawling', /^User-agent:\s*\*/mi.test(robots) && /^Allow:\s*\/\s*$/mi.test(robots) && !/^Disallow:\s*\/\s*$/mi.test(robots));

if (cfg.siteUrl) {
  const canonical = (html.match(/<link rel="canonical" href="([^"]*)"/) || [])[1];
  check('canonical is the configured address', canonical === `${cfg.siteUrl}/`, String(canonical));
  check('og:url is the configured address', metaContent('property', 'og:url') === `${cfg.siteUrl}/`);
  check('og:image is absolute and on the configured address', metaContent('property', 'og:image') === `${cfg.siteUrl}/og-image.png`);
  check('twitter:card is summary_large_image with an image', metaContent('name', 'twitter:card') === 'summary_large_image' && metaContent('name', 'twitter:image') === `${cfg.siteUrl}/og-image.png`);
  check('JSON-LD includes a WebSite node', graph.some((n) => n['@type'] === 'WebSite' && n.url === `${cfg.siteUrl}/`));
  check('sitemap.xml lists the home page', exists('sitemap.xml') && fs.readFileSync(path.join(DIR, 'sitemap.xml'), 'utf8').includes(`<loc>${cfg.siteUrl}/</loc>`));
  check('robots.txt points at the sitemap', robots.includes(`Sitemap: ${cfg.siteUrl}/sitemap.xml`));
} else {
  check(
    'no siteUrl: no canonical, og:url, og:image or twitter:image (nothing is invented)',
    !/rel="canonical"/.test(html) && !/property="og:url"/.test(html) && !/property="og:image"/.test(html) && !/name="twitter:image"/.test(html),
  );
  check('no siteUrl: no WebSite data, no sitemap, no Sitemap line', !graph.some((n) => n['@type'] === 'WebSite') && !exists('sitemap.xml') && !/Sitemap:/i.test(robots));
  note('siteUrl is empty, so the canonical link, social image tags and sitemap are left out until you supply it.');
}

if (exists('og-image.png')) {
  const png = fs.readFileSync(path.join(DIR, 'og-image.png'));
  const isPng = png.length > 24 && png.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  check('og-image.png is a 1200 by 630 PNG', isPng && png.readUInt32BE(16) === 1200 && png.readUInt32BE(20) === 630);
} else {
  check('og-image.png exists', false, 'Run "npm run og" and build again.');
}

// ---------------------------------------------------------------- form and analytics
const hasFormTag = count(/<form\b/g) > 0;
const expectForm = Boolean(cfg.formEndpoint || cfg.email);
check(`contact form ${expectForm ? 'is present' : 'is absent'} to match the config`, hasFormTag === expectForm);
if (expectForm) {
  check('form fields have labels', ['f-name', 'f-email', 'f-message'].every((id) => new RegExp(`<label[^>]*\\sfor="${id}"`).test(html)));
  check('form has a polite live status region', /<p id="form-status" role="status" aria-live="polite"/.test(html));
  check('form has a honeypot field', /name="_gotcha"/.test(html));
  check('the status region starts empty (no success message in the markup)', /id="form-status"[^>]*><\/p>/.test(html) && !/Message sent/.test(visible));
  if (cfg.formEndpoint) {
    const action = (html.match(/<form[^>]*\saction="([^"]*)"/) || [])[1];
    check('endpoint mode: the form posts to the configured endpoint', /data-mode="endpoint"/.test(html) && decode(action || '') === cfg.formEndpoint);
  } else {
    check('email mode: no action attribute, and the page says nothing is sent until the visitor sends it', /data-mode="mailto"/.test(html) && !/<form[^>]*\saction=/.test(html) && /Nothing is sent until you press send there/.test(visible));
  }
} else {
  check('no form: the page says contact details are not published yet', /Contact details are not published yet\./.test(visible));
}

const plausible = /<script defer data-domain="([^"]+)" src="https:\/\/plausible\.io\/js\/script\.js"><\/script>/.exec(html);
if (cfg.plausibleDomain) {
  check('analytics script is present for the configured domain', Boolean(plausible) && plausible[1] === cfg.plausibleDomain);
} else {
  check('no analytics code without a configured domain', !/plausible/i.test(html));
}

// ---------------------------------------------------------------- size
const bytes = Buffer.byteLength(html);
check(`index.html is under 120 KB (${(bytes / 1024).toFixed(1)} KB)`, bytes < 120 * 1024);
const walk = (dir) =>
  fs.readdirSync(dir, { withFileTypes: true }).reduce((sum, e) => {
    const p = path.join(dir, e.name);
    return sum + (e.isDirectory() ? walk(p) : fs.statSync(p).size);
  }, 0);
note(`output folder total: ${(walk(DIR) / 1024).toFixed(0)} KB`);

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
