// Shared by build.mjs and check.mjs, so both read the configuration the same way.
//
// Source of truth: site.config.json (or the file named in SITE_CONFIG).
// Environment overrides: SITE_URL, CONTACT_EMAIL, FORM_ENDPOINT, PLAUSIBLE_DOMAIN.
// A bad value is reported in `errors` and replaced with '' so nothing invalid ships.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DOMAIN_RE = /^[a-z0-9.-]+\.[a-z]{2,}$/i;
const str = (v) => (typeof v === 'string' ? v.trim() : '');

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

export function loadConfig() {
  const file = process.env.SITE_CONFIG
    ? path.resolve(process.env.SITE_CONFIG)
    : path.join(ROOT, 'site.config.json');
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const errors = [];
  const pick = (envName, fromFile) => str(process.env[envName]) || str(fromFile);

  let siteUrl = pick('SITE_URL', raw.siteUrl).replace(/\/+$/, '');
  if (siteUrl) {
    let ok = false;
    try {
      const u = new URL(siteUrl);
      ok = u.protocol === 'https:' || (u.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(u.hostname));
    } catch {
      ok = false;
    }
    if (!ok) {
      errors.push(`siteUrl "${siteUrl}" must be a full https:// address.`);
      siteUrl = '';
    }
  }

  let email = pick('CONTACT_EMAIL', raw.email);
  if (email && !EMAIL_RE.test(email)) {
    errors.push(`email "${email}" is not a valid address.`);
    email = '';
  }

  let formEndpoint = pick('FORM_ENDPOINT', raw.formEndpoint);
  if (formEndpoint && !/^https:\/\/\S+$/.test(formEndpoint)) {
    errors.push('formEndpoint must be a full https:// address.');
    formEndpoint = '';
  }

  let plausibleDomain = pick('PLAUSIBLE_DOMAIN', raw.analytics && raw.analytics.plausibleDomain);
  if (plausibleDomain && !DOMAIN_RE.test(plausibleDomain)) {
    errors.push(`analytics.plausibleDomain "${plausibleDomain}" must be a bare domain such as yourname.dev.`);
    plausibleDomain = '';
  }

  const links = {};
  for (const [key, value] of Object.entries(raw.links || {})) {
    const url = str(value);
    if (url && !isHttpUrl(url)) {
      errors.push(`links.${key} must be an http(s) address.`);
      links[key] = '';
    } else {
      links[key] = url;
    }
  }

  const hidden = {};
  for (const [k, v] of Object.entries(raw.formHiddenFields || {})) hidden[k] = String(v);

  return { siteUrl, email, formEndpoint, plausibleDomain, links, hidden, errors };
}

// The keys a template can test with <!--#if key--> and print with {{key}}.
export function buildValues(c) {
  const hasForm = Boolean(c.formEndpoint);
  const hasMailto = !hasForm && Boolean(c.email);
  const values = {
    siteUrl: c.siteUrl,
    email: c.email,
    formEndpoint: c.formEndpoint,
    plausibleDomain: c.plausibleDomain,
    hasForm: hasForm ? 'yes' : '',
    hasMailto: hasMailto ? 'yes' : '',
    hasContact: hasForm || hasMailto ? 'yes' : '',
    formMode: hasForm ? 'endpoint' : hasMailto ? 'mailto' : '',
    formButton: hasForm ? 'Send message' : 'Open in my email app',
  };
  for (const [key, url] of Object.entries(c.links)) values[`link.${key}`] = url;
  return values;
}
