// Browser checks (Playwright + axe-core): layout, accessibility, theme, navigation, motion,
// the no-JavaScript fallback, and every path through the contact form.
//
// The shipped build (dist/) is tested as it is. The contact form is tested on throwaway builds
// made from a copy of the config with test-only values, so nothing here touches site.config.json.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { ROOT, loadConfig } from './config.mjs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const AXE = path.join(ROOT, 'node_modules', 'axe-core', 'axe.min.js');
const SHOTS = path.join(ROOT, 'screenshots');
const CACHE = path.join(ROOT, '.build-cache');
const BLANK_ENV = { SITE_URL: '', CONTACT_EMAIL: '', FORM_ENDPOINT: '', PLAUSIBLE_DOMAIN: '' };

const VIEWPORTS = [
  { name: 'phone', width: 390, height: 844 },
  { name: 'tablet', width: 820, height: 1100 },
  { name: 'desktop', width: 1440, height: 900 },
];

const GOOD = {
  name: 'Ada Obi',
  email: 'ada@sender.test',
  message: 'We need a booking dashboard for our studio before March. Can we talk this week?',
};

let passed = 0;
let failed = 0;
function check(name, ok, detail = '') {
  if (ok) {
    passed += 1;
    console.log(`PASS  ${name}`);
  } else {
    failed += 1;
    console.log(`FAIL  ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
  '.xml': 'application/xml',
  '.txt': 'text/plain',
  '.json': 'application/json',
};

function serve(dir) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      const urlPath = decodeURIComponent(new URL(req.url, 'http://local').pathname);
      const file = path.join(dir, urlPath === '/' ? 'index.html' : urlPath);
      if (!file.startsWith(dir)) {
        res.writeHead(403);
        res.end();
        return;
      }
      fs.readFile(file, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end('not found');
          return;
        }
        res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
        res.end(data);
      });
    });
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: `http://127.0.0.1:${server.address().port}`,
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}

function buildVariant(name, env = {}) {
  fs.mkdirSync(CACHE, { recursive: true });
  const base = JSON.parse(fs.readFileSync(path.join(ROOT, 'site.config.json'), 'utf8'));
  const cfgPath = path.join(CACHE, `${name}.config.json`);
  fs.writeFileSync(
    cfgPath,
    JSON.stringify({ ...base, siteUrl: '', email: '', formEndpoint: '', analytics: { plausibleDomain: '' } }, null, 2),
  );
  const out = path.join(CACHE, `variant-${name}`);
  const variantEnv = { ...BLANK_ENV, SITE_CONFIG: cfgPath, ...env };
  execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'build.mjs')], {
    cwd: ROOT,
    env: { ...process.env, ...variantEnv, OUT_DIR: out },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  return { out, env: variantEnv };
}

function staticCheck(dir, env) {
  try {
    const out = execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'check.mjs')], {
      cwd: ROOT,
      env: { ...process.env, ...env, CHECK_DIR: dir },
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    return { ok: true, out };
  } catch (e) {
    return { ok: false, out: `${e.stdout || ''}${e.stderr || ''}` };
  }
}

async function newPage(browser, opts) {
  const { width, height, colorScheme = 'light', reducedMotion = 'no-preference', javaScriptEnabled = true } = opts;
  const context = await browser.newContext({
    viewport: { width, height },
    colorScheme,
    reducedMotion,
    javaScriptEnabled,
    deviceScaleFactor: 1,
  });
  const page = await context.newPage();
  const problems = [];
  page.on('console', (m) => {
    if (m.type() === 'error') problems.push(`console: ${m.text()}`);
  });
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('requestfailed', (r) => problems.push(`requestfailed: ${r.url()}`));
  page.on('response', (r) => {
    if (r.status() >= 400) problems.push(`http ${r.status()}: ${r.url()}`);
  });
  return { context, page, problems };
}

async function fillForm(page, v = GOOD) {
  await page.fill('#f-name', v.name);
  await page.fill('#f-email', v.email);
  await page.fill('#f-message', v.message);
}

const statusOf = (page) =>
  page.evaluate(() => {
    const el = document.getElementById('form-status');
    return { text: el.textContent.trim(), state: el.getAttribute('data-state') || '' };
  });

// ------------------------------------------------------------------ layout, a11y, screenshots
async function layoutSuite(browser, baseUrl) {
  fs.mkdirSync(SHOTS, { recursive: true });
  for (const vp of VIEWPORTS) {
    for (const theme of ['light', 'dark']) {
      const label = `${vp.name}/${theme}`;
      const { context, page, problems } = await newPage(browser, { width: vp.width, height: vp.height, colorScheme: theme });
      await page.goto(baseUrl, { waitUntil: 'networkidle' });
      const fonts = await page.evaluate(async () => {
        await Promise.all([document.fonts.load('1em Anton'), document.fonts.load('800 1em Manrope')]);
        return { anton: document.fonts.check('1em Anton'), manrope: document.fonts.check('800 1em Manrope') };
      });
      const geo = await page.evaluate(() => {
        const vw = document.documentElement.clientWidth;
        const bad = [];
        for (const el of document.querySelectorAll('body *')) {
          const r = el.getBoundingClientRect();
          if (r.width === 0 && r.height === 0) continue;
          if (r.right > vw + 1) bad.push(`${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ''} right=${Math.round(r.right)}`);
        }
        return {
          vw,
          scrollWidth: document.documentElement.scrollWidth,
          bad: bad.slice(0, 8),
          dark: document.documentElement.classList.contains('dark'),
        };
      });
      check(`${label}: no console errors, page errors or failed requests`, problems.length === 0, problems.join(' | '));
      check(`${label}: no horizontal scroll`, geo.scrollWidth <= geo.vw, `${geo.scrollWidth} > ${geo.vw}`);
      check(`${label}: no element runs past the right edge`, geo.bad.length === 0, geo.bad.join(' | '));
      check(`${label}: theme follows the system setting`, geo.dark === (theme === 'dark'));
      check(`${label}: Anton and Manrope are loaded`, fonts.anton && fonts.manrope, JSON.stringify(fonts));

      await page.addScriptTag({ path: AXE });
      const violations = await page.evaluate(() =>
        window.axe
          .run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] } })
          .then((r) =>
            r.violations.map((v) => ({
              id: v.id,
              impact: v.impact,
              count: v.nodes.length,
              where: v.nodes.slice(0, 3).map((n) => n.target.join(' ')),
            })),
          ),
      );
      const major = violations.filter((v) => ['serious', 'critical'].includes(v.impact));
      const minor = violations.filter((v) => !['serious', 'critical'].includes(v.impact));
      const show = (list) => list.map((v) => `${v.id} x${v.count} (${v.where.join('; ')})`).join(' | ');
      check(`${label}: axe finds no serious or critical issues`, major.length === 0, show(major));
      check(`${label}: axe finds no moderate or minor issues`, minor.length === 0, show(minor));

      await page.waitForTimeout(1400); // let the hero rules finish drawing
      await page.screenshot({ path: path.join(SHOTS, `home-${vp.name}-${theme}.jpg`), fullPage: true, type: 'jpeg', quality: 72 });
      await context.close();
    }
  }
}

// ------------------------------------------------------------------ interaction
async function interactionSuite(browser, baseUrl) {
  // Theme toggle
  {
    const { context, page } = await newPage(browser, { width: 1440, height: 900, colorScheme: 'light' });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    const btn = page.locator('#theme-toggle');
    check('theme toggle starts unpressed in light mode', (await btn.getAttribute('aria-pressed')) === 'false');
    await btn.click();
    check('theme toggle switches to dark', await page.evaluate(() => document.documentElement.classList.contains('dark')));
    check('theme toggle reports pressed', (await btn.getAttribute('aria-pressed')) === 'true');
    await page.reload({ waitUntil: 'networkidle' });
    check('the chosen theme survives a reload', await page.evaluate(() => document.documentElement.classList.contains('dark')));
    await page.locator('#theme-toggle').click();
    check('theme toggle switches back to light', await page.evaluate(() => !document.documentElement.classList.contains('dark')));
    await context.close();
  }

  // Keyboard: skip link and focus ring
  {
    const { context, page } = await newPage(browser, { width: 1440, height: 900 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.keyboard.press('Tab');
    const first = await page.evaluate(() => {
      const el = document.activeElement;
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return { text: el.textContent.trim(), w: r.width, h: r.height, top: r.top, ow: cs.outlineWidth, os: cs.outlineStyle };
    });
    check('first Tab stop is the "Skip to content" link', first.text === 'Skip to content', first.text);
    check('the skip link is visible when focused', first.w > 40 && first.h > 20 && first.top >= 0);
    check('the focus outline is 3px solid', first.ow === '3px' && first.os === 'solid', `${first.ow} ${first.os}`);
    await context.close();
  }

  // Scroll spy
  {
    const { context, page } = await newPage(browser, { width: 1440, height: 900 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.evaluate(() => document.getElementById('work').scrollIntoView());
    const marked = await page
      .waitForFunction(
        () => {
          const a = document.querySelector('#nav-links a[aria-current="true"]');
          return Boolean(a) && a.textContent.trim() === 'Work';
        },
        null,
        { timeout: 8000 },
      )
      .then(() => true)
      .catch(() => false);
    check('scroll spy marks "Work" while the Work section is in view', marked);
    check('exactly one navigation link is current', (await page.locator('#nav-links a[aria-current="true"]').count()) === 1);
    check('desktop: the navigation is inline and the Menu button is hidden', (await page.locator('#nav-links').isVisible()) && !(await page.locator('#menu-btn').isVisible()));
    await context.close();
  }

  // Reduced motion and normal motion
  {
    const probe = () =>
      document.fonts.ready.then(() => ({
        anim: getComputedStyle(document.querySelector('.hero-note'), '::before').animationName,
        smooth: getComputedStyle(document.documentElement).scrollBehavior,
      }));
    const calm = await newPage(browser, { width: 1440, height: 900, reducedMotion: 'reduce' });
    await calm.page.goto(baseUrl, { waitUntil: 'networkidle' });
    const rm = await calm.page.evaluate(probe);
    check('reduced motion: the hero rules do not animate', rm.anim === 'none', rm.anim);
    check('reduced motion: smooth scrolling is off', rm.smooth === 'auto', rm.smooth);
    await calm.context.close();
    const lively = await newPage(browser, { width: 1440, height: 900, reducedMotion: 'no-preference' });
    await lively.page.goto(baseUrl, { waitUntil: 'networkidle' });
    const nm = await lively.page.evaluate(probe);
    check('normal motion: the hero rules draw in', nm.anim === 'draw', nm.anim);
    await lively.context.close();
  }

  // Phone menu
  {
    const { context, page } = await newPage(browser, { width: 390, height: 844 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    const list = page.locator('#nav-links');
    const btn = page.locator('#menu-btn');
    check('phone menu: collapsed at first', !(await list.isVisible()) && (await btn.getAttribute('aria-expanded')) === 'false');
    await btn.click();
    check('phone menu: the Menu button opens it', (await list.isVisible()) && (await btn.getAttribute('aria-expanded')) === 'true');
    await page.keyboard.press('Escape');
    check(
      'phone menu: Escape closes it and returns focus to the button',
      !(await list.isVisible()) && (await page.evaluate(() => document.activeElement.id)) === 'menu-btn',
    );
    await btn.click();
    await page.click('#nav-links a[href="#contact"]');
    check('phone menu: choosing a link closes the menu', !(await list.isVisible()));
    const arrived = await page
      .waitForFunction(
        () => {
          const top = document.getElementById('contact').getBoundingClientRect().top;
          return top >= 0 && top < 420;
        },
        null,
        { timeout: 8000 },
      )
      .then(() => true)
      .catch(() => false);
    check('phone menu: the chosen section scrolls into view', arrived);
    await context.close();
  }
}

// ------------------------------------------------------------------ no JavaScript
async function noJsSuite(browser, baseUrl) {
  const { context, page } = await newPage(browser, { width: 390, height: 844, javaScriptEnabled: false });
  await page.goto(baseUrl, { waitUntil: 'load' });
  check('no JavaScript: the headline is visible', await page.locator('h1').isVisible());
  check('no JavaScript: the navigation is open', await page.locator('#nav-links').isVisible());
  check('no JavaScript: the Menu button is hidden', !(await page.locator('#menu-btn').isVisible()));
  check('no JavaScript: the contact section renders', await page.locator('#contact').isVisible());
  check('no JavaScript: the case study text is in the page', (await page.locator('#ghonsi-proof').innerText()).includes('A line on a CV'));
  await context.close();
}

// ------------------------------------------------------------------ what the shipped config produces
async function configStateSuite(browser, baseUrl, cfg) {
  const { context, page } = await newPage(browser, { width: 1280, height: 900 });
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  const state = await page.evaluate(() => ({
    canonical: Boolean(document.querySelector('link[rel="canonical"]')),
    ogImage: Boolean(document.querySelector('meta[property="og:image"]')),
    form: Boolean(document.getElementById('contact-form')),
    contactText: document.getElementById('contact').innerText,
    plausible: Boolean(document.querySelector('script[src*="plausible"]')),
  }));
  const hasContact = Boolean(cfg.email || cfg.formEndpoint);
  check(`shipped config: ${cfg.siteUrl ? 'canonical and og:image are set' : 'no canonical and no og:image (siteUrl is empty)'}`, state.canonical === Boolean(cfg.siteUrl) && state.ogImage === Boolean(cfg.siteUrl));
  check(
    `shipped config: ${hasContact ? 'the contact form is present' : 'no form, and the page says contact details are not published yet'}`,
    hasContact ? state.form : !state.form && state.contactText.includes('Contact details are not published yet.'),
  );
  check(`shipped config: analytics ${cfg.plausibleDomain ? 'are loaded' : 'are off'}`, state.plausible === Boolean(cfg.plausibleDomain));
  await context.close();
}

// ------------------------------------------------------------------ contact form with an endpoint
async function endpointSuite(browser) {
  const variant = buildVariant('endpoint', {
    SITE_URL: 'https://portfolio.test',
    CONTACT_EMAIL: 'hello@portfolio.test',
    FORM_ENDPOINT: 'https://forms.test/f/abc123',
    PLAUSIBLE_DOMAIN: 'portfolio.test',
  });
  const sc = staticCheck(variant.out, variant.env);
  check(
    'endpoint build passes every static check',
    sc.ok,
    sc.out.split('\n').filter((l) => l.startsWith('FAIL')).join(' | '),
  );
  const server = await serve(variant.out);

  async function open(mode) {
    const { context, page, problems } = await newPage(browser, { width: 1280, height: 900 });
    const posts = [];
    await page.route('https://plausible.io/**', (route) => route.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    await page.route('https://forms.test/**', async (route) => {
      const req = route.request();
      posts.push({ method: req.method(), accept: req.headers().accept || '', body: req.postData() || '' });
      const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*' };
      if (mode === 'network') return route.abort('failed');
      if (mode === 'ok') {
        await new Promise((r) => setTimeout(r, 400));
        return route.fulfill({ status: 200, headers: cors, contentType: 'application/json', body: JSON.stringify({ success: true }) });
      }
      if (mode === 'rejected') {
        return route.fulfill({ status: 200, headers: cors, contentType: 'application/json', body: JSON.stringify({ success: false, message: 'Invalid access key' }) });
      }
      return route.fulfill({ status: 500, headers: cors, contentType: 'text/plain', body: 'Server error' });
    });
    await page.goto(server.url, { waitUntil: 'networkidle' });
    return { context, page, problems, posts };
  }

  try {
    const A = await open('ok');
    const { page } = A;
    check('endpoint page loads with no console errors, page errors or failed requests', A.problems.length === 0, A.problems.join(' | '));
    const head = await page.evaluate(() => ({
      canonical: (document.querySelector('link[rel="canonical"]') || {}).href,
      ogImage: (document.querySelector('meta[property="og:image"]') || {}).content,
      card: (document.querySelector('meta[name="twitter:card"]') || {}).content,
    }));
    check('head carries the canonical, og:image and the large Twitter card for the site URL', head.canonical === 'https://portfolio.test/' && head.ogImage === 'https://portfolio.test/og-image.png' && head.card === 'summary_large_image', JSON.stringify(head));
    const formInfo = await page.evaluate(() => {
      const f = document.getElementById('contact-form');
      return { action: f.action, mode: f.getAttribute('data-mode'), button: document.getElementById('form-submit').textContent.trim() };
    });
    check('endpoint mode: the button says "Send message" and the form posts to the endpoint', formInfo.button === 'Send message' && formInfo.action === 'https://forms.test/f/abc123' && formInfo.mode === 'endpoint', JSON.stringify(formInfo));

    await page.click('[data-track="hero-work"]');
    const queue = await page.evaluate(() => ((window.plausible && window.plausible.q) || []).map((a) => [a[0], a[1] && a[1].props && a[1].props.target]));
    check('analytics: a click on a tracked button is queued as "Click" with its target', queue.some(([n, t]) => n === 'Click' && t === 'hero-work'), JSON.stringify(queue));

    // Validation
    await page.click('#form-submit');
    const errs = await page.evaluate(() => ['name', 'email', 'message'].map((k) => {
      const e = document.getElementById(`err-${k}`);
      return { hidden: e.hidden, text: e.textContent.trim() };
    }));
    check('an empty submit shows three inline errors', errs.every((e) => !e.hidden && e.text), JSON.stringify(errs));
    check('an empty submit sends nothing', A.posts.length === 0);
    check('the first invalid field is focused and marked invalid', await page.evaluate(() => document.activeElement.id === 'f-name' && document.activeElement.getAttribute('aria-invalid') === 'true'));
    const summary = await statusOf(page);
    check('the status line says the marked fields need fixing', summary.text === 'Please fix the fields marked above.' && summary.state === 'error', JSON.stringify(summary));

    await fillForm(page, { ...GOOD, email: 'not-an-email' });
    await page.click('#form-submit');
    const bad = await page.evaluate(() => ['name', 'email', 'message'].map((k) => document.getElementById(`err-${k}`).textContent.trim()));
    check('a bad email address is rejected, and only that field complains', bad[0] === '' && bad[1] === 'Please enter a valid email address.' && bad[2] === '', JSON.stringify(bad));
    check('a bad email address sends nothing', A.posts.length === 0);

    await fillForm(page, { ...GOOD, message: 'too short' });
    await page.click('#form-submit');
    const short = await page.evaluate(() => ['name', 'email', 'message'].map((k) => document.getElementById(`err-${k}`).textContent.trim()));
    check('a message under 20 characters is rejected', short[2] === 'Please write at least 20 characters so I know what you need.' && short[0] === '' && short[1] === '', JSON.stringify(short));
    check('a short message sends nothing', A.posts.length === 0);

    // Success
    await fillForm(page);
    await page.click('#form-submit');
    const during = await page.evaluate(() => {
      const b = document.getElementById('form-submit');
      return { text: b.textContent.trim(), disabled: b.disabled };
    });
    check('while sending, the button is disabled and says "Sending"', during.text === 'Sending' && during.disabled, JSON.stringify(during));
    await page.waitForSelector('#form-status[data-state="ok"]', { timeout: 5000 });
    const ok = await statusOf(page);
    check('success is shown only after the server accepts the message', ok.text.startsWith('Message sent.') && ok.state === 'ok', JSON.stringify(ok));
    check('the form is cleared and the button is restored after success', await page.evaluate(() => document.getElementById('f-name').value === '' && document.getElementById('f-message').value === '' && !document.getElementById('form-submit').disabled && document.getElementById('form-submit').textContent.trim() === 'Send message'));
    const post = A.posts[0] || {};
    check('exactly one POST was sent, asking for JSON and carrying the fields', A.posts.length === 1 && post.method === 'POST' && post.accept.includes('application/json') && post.body.includes(GOOD.name) && post.body.includes(GOOD.email) && post.body.includes(GOOD.message), JSON.stringify({ n: A.posts.length, method: post.method, accept: post.accept }));
    await A.context.close();

    // Failure modes
    const modes = [
      ['rejected', 'the server answers 200 but says success is false'],
      ['server', 'the server answers 500'],
      ['network', 'the network request fails'],
    ];
    for (const [mode, label] of modes) {
      const B = await open(mode);
      await fillForm(B.page);
      await B.page.click('#form-submit');
      await B.page.waitForSelector('#form-status[data-state="error"]', { timeout: 5000 });
      const st = await statusOf(B.page);
      check(`${label}: the page says the message was not sent`, st.text.includes('was not sent') && !/Message sent/i.test(st.text) && st.state === 'error', JSON.stringify(st));
      check(`${label}: the visitor's text is kept and the button works again`, await B.page.evaluate(() => document.getElementById('f-message').value.length > 20 && !document.getElementById('form-submit').disabled));
      check(`${label}: the failure text offers the fallback email`, st.text.includes('hello@portfolio.test'), st.text);
      await B.context.close();
    }

    // Honeypot
    const H = await open('ok');
    await fillForm(H.page);
    await H.page.evaluate(() => { document.querySelector('[name="_gotcha"]').value = 'bot'; });
    await H.page.click('#form-submit');
    await H.page.waitForTimeout(700);
    const hs = await statusOf(H.page);
    check('honeypot: a filled trap field sends nothing and shows no success', H.posts.length === 0 && !/Message sent/i.test(hs.text), JSON.stringify({ posts: H.posts.length, hs }));
    await H.context.close();
  } finally {
    await server.close();
  }
}

// ------------------------------------------------------------------ contact form in email mode
async function mailtoSuite(browser) {
  const variant = buildVariant('mailto', { CONTACT_EMAIL: 'hello@portfolio.test' });
  const sc = staticCheck(variant.out, variant.env);
  check('email-mode build passes every static check', sc.ok, sc.out.split('\n').filter((l) => l.startsWith('FAIL')).join(' | '));
  const server = await serve(variant.out);
  try {
    const { context, page, problems } = await newPage(browser, { width: 1280, height: 900 });
    const outside = [];
    page.on('request', (r) => {
      if (!r.url().startsWith(server.url)) outside.push(r.url());
    });
    await page.goto(server.url, { waitUntil: 'networkidle' });
    check('email mode: page loads with no console errors or failed requests', problems.length === 0, problems.join(' | '));
    const info = await page.evaluate(() => ({
      button: document.getElementById('form-submit').textContent.trim(),
      action: document.getElementById('contact-form').getAttribute('action'),
      mode: document.getElementById('contact-form').getAttribute('data-mode'),
      note: document.getElementById('contact').innerText.includes('Nothing is sent until you press send there.'),
    }));
    check('email mode: the button says "Open in my email app" and the form has no action', info.button === 'Open in my email app' && info.action === null && info.mode === 'mailto', JSON.stringify(info));
    check('email mode: the page says nothing is sent until the visitor presses send', info.note);

    await page.evaluate(() => {
      window.__mail = [];
      document.addEventListener(
        'click',
        (e) => {
          const a = e.target.closest && e.target.closest('a');
          const href = a && a.getAttribute('href');
          if (href && href.startsWith('mailto:')) {
            window.__mail.push(href);
            e.preventDefault();
          }
        },
        true,
      );
    });
    await page.click('#form-submit');
    const empty = await statusOf(page);
    check('email mode: an empty submit is refused with the same inline errors', empty.state === 'error' && (await page.evaluate(() => !document.getElementById('err-name').hidden)));
    check('email mode: an empty submit opens no email', (await page.evaluate(() => window.__mail.length)) === 0);

    await fillForm(page);
    await page.click('#form-submit');
    const mail = await page.evaluate(() => window.__mail);
    check('email mode: a valid submit builds exactly one mailto link', mail.length === 1, JSON.stringify(mail));
    if (mail.length === 1) {
      const u = new URL(mail[0]);
      check('email mode: the link goes to the configured address', decodeURIComponent(u.pathname) === 'hello@portfolio.test', u.pathname);
      check('email mode: the subject names the sender', u.searchParams.get('subject') === 'Portfolio enquiry from Ada Obi', u.searchParams.get('subject'));
      const body = u.searchParams.get('body') || '';
      check('email mode: the body carries the message, the name and the sender email', body.includes(GOOD.message) && body.includes(GOOD.name) && body.includes(GOOD.email), body);
    }
    const st = await statusOf(page);
    check('email mode: the status says the email app should open and nothing has been sent', st.state === 'ok' && st.text.includes('Nothing has been sent until you press send there.') && !/Message sent/i.test(st.text), JSON.stringify(st));
    check('email mode: no network request left the page', outside.length === 0, outside.join(', '));
    await context.close();

    const nojs = await newPage(browser, { width: 390, height: 844, javaScriptEnabled: false });
    await nojs.page.goto(server.url, { waitUntil: 'load' });
    check('email mode without JavaScript: the form is hidden', !(await nojs.page.locator('#contact-form').isVisible()));
    check('email mode without JavaScript: the mailto link is visible', await nojs.page.locator('#contact a[href^="mailto:"]').first().isVisible());
    check('email mode without JavaScript: the page explains why', (await nojs.page.locator('#contact').innerText()).includes('This form needs JavaScript'));
    await nojs.context.close();
  } finally {
    await server.close();
  }
}

async function main() {
  const cfg = loadConfig();
  const browser = await chromium.launch();
  try {
    const dist = path.join(ROOT, 'dist');
    if (!fs.existsSync(path.join(dist, 'index.html'))) throw new Error('dist/index.html is missing. Run "npm run build" first.');
    const server = await serve(dist);
    try {
      console.log('\n== Shipped build (dist) ==');
      await layoutSuite(browser, server.url);
      await interactionSuite(browser, server.url);
      await noJsSuite(browser, server.url);
      await configStateSuite(browser, server.url, cfg);
    } finally {
      await server.close();
    }
    console.log('\n== Contact form with an endpoint (test values) ==');
    await endpointSuite(browser);
    console.log('\n== Contact form in email mode (test values) ==');
    await mailtoSuite(browser);
  } finally {
    await browser.close();
  }
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
