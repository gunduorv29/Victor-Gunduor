/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.html'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        paper: 'rgb(var(--paper) / <alpha-value>)',
        panel: 'rgb(var(--panel) / <alpha-value>)',
        ink: 'rgb(var(--ink) / <alpha-value>)',
        muted: 'rgb(var(--muted) / <alpha-value>)',
        rule: 'rgb(var(--rule) / <alpha-value>)',
        gold: 'rgb(var(--gold) / <alpha-value>)',
        bronze: 'rgb(var(--bronze) / <alpha-value>)',
      },
      fontFamily: {
        display: ['Anton', 'Impact', 'Haettenschweiler', '"Arial Narrow Bold"', 'sans-serif'],
        body: ['Manrope', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
      maxWidth: { copy: '66ch' },
    },
  },
  plugins: [],
};
