# Handoff: Victor Gunduor portfolio

Built 24 November 2026. The site is built, tested and ready to deploy. Three things stand between you and a live link: a contact route, a domain, and a few fixes in your public repos (section 10).

## 0. Read this first

- **Contact currently says "Contact details are not published yet."** That is deliberate. No email or form endpoint was supplied, so there is no form, no address and no dead button. Supply one (section 7) and rebuild: two minutes. I did not publish your account email without your say-so.
- **Your public repos need fixing first** (section 10): committed keys, and old or sample content that contradicts this page. A recruiter who clicks through will see it. Fix before you send the link.
- Nothing on the page is invented. 23 sentences come from your own account and have no public source. They are listed in `claims-report.txt` and section 11. Confirm each one or delete the line.

## 1. Summary

- Your Stackweck page is now a static personal portfolio. HTML with the Tailwind CSS compiled and inlined, Anton and Manrope self-hosted, inline icons, no CDN, no framework at runtime. `index.html` is 50 KB. Content is in the markup, so search engines and recruiters' tools read it without running scripts.
- Order: hero (your three lines) / About / Selected work / Ghonsi Proof case study / How I build / Writing and research / Skills / Contact. Light and dark themes, keyboard and screen-reader friendly, reduced-motion respected.
- Work section: three projects in depth (Ghonsi Proof, Perfect Fingers, Speaking Virtue), three smaller builds (PotAlert, AuthGuard, Stackweck). Each says what it does, what it does not do yet, and where to check.
- Everything configurable lives in `site.config.json`. An empty value hides the block that uses it.
- Kraken Orderbook is removed completely, along with every invented number (section 5).
- Call to action buttons: View my work, Get in touch, View GitHub. GitHub is your real profile. Nothing else is linked unless you supply it.

## 2. Projects selected, and why

| Project | Why it is on the page |
| --- | --- |
| Ghonsi Proof | Your strongest story: a Solana product, a Chainlink hackathon entry that credits four builders including you, and work you describe in detail (migration, data security, payments, wallets). It gets a card and a full case study. |
| Perfect Fingers | Public repo, all commits yours, a real schema with row-level security, an admin dashboard, and (by your account) a client who uses it. Strongest code evidence you have. |
| Speaking Virtue | Public repos for the web page, the Express payments backend and the Expo app. Shows payment handling and webhook checks. |
| PotAlert, AuthGuard, Stackweck | Labelled "smaller builds". Each states its limits plainly (browser-only storage, no server, never grew past the interface). |

"Two credible projects are better than five questionable ones." Three projects carry the page. The small builds are there because the code exists and the limits are written next to them.

**Left out on purpose:** the job crawler (a teammate's project), AbuGem (client status unverified), the Colosseum Frontier listing (unverified), Young Gems Initiative (no description yet), the Multigate.io SIWES placement (unconfirmed), your NOUN course exercises and study wizards, and your job at FHLU (privacy; add it if you want it, one line).

## 3. Evidence

| Claim on the page | Source | Strength |
| --- | --- | --- |
| Perfect Fingers: React 19, Vite, Tailwind, Supabase, TanStack Query, Recharts, 4 tables, RLS on all 4, 11 policies | Public repo: 13 commits, 26 Mar to 19 May 2026, all by you. `package.json` and `supabase/schema.sql` | Public code |
| Perfect Fingers: confirm, complete, cancel, blocked days, 7-day revenue chart | Admin pages in the repo | Public code |
| Perfect Fingers: taken slots hidden in the interface only | Booking page code; no uniqueness rule in the schema | Public code |
| Speaking Virtue: Paystack and Flutterwave, initiate, verify, webhooks, signature checks | Public repo: 31 commits, 30 Dec 2025 to 12 Mar 2026 (25 as "Victor Gunduor", 6 as "gunduorv29") | Public code |
| Speaking Virtue: carts held in server memory | `carts[sessionId]` in the backend | Public code |
| Speaking Virtue app: Expo 54, React Native, TypeScript | `svirtue` repo, 7 commits, 14 Jan to 11 Mar 2026 | Public code |
| PotAlert: photo, GPS, OpenStreetMap street lookup, map pin; reports kept in the browser | Public repo: 3 commits, 3 Sep 2026, one `index.html` | Public code |
| AuthGuard: WebAuthn, code made in the browser, accounts in the browser | Public repo: 7 commits, 1 Sep 2026, one `index.html` | Public code |
| Stackweck: first idea for the site, 2025 | First commit 23 Dec 2025 | Public code |
| Ghonsi Proof: Convergence hackathon, CRE and AI track, four builders including you, the proof flow | `chain.link/hack-26/projects/ghonsi-proof` | Public page |
| Ghonsi Proof: co-founder, Next.js 15, React 19, Supabase, Express on Render, the migration, 49-table audit, USDT payments and replay check, Phantom flow, custodial wallet, hirer invites, AI chat page | Your account. The repo (`ghonsiproof/Ghonsi-Proof-CRE-AI`) refused access from my environment | Your word |
| Writing, video contests, client names, research engagements, 100+ bookings, Scofield Creativity, freeCodeCamp | Your account | Your word |

Anything marked "Your word" carries a `data-claim` marker in `src/index.html` so it cannot slip through unnoticed.

## 4. Files created

Everything is new; your original Stackweck page was left untouched.

```
site.config.json            the only file you normally edit
src/index.html              the page (template)
src/input.css               Tailwind entry, theme tokens, components
src/favicon.svg             new VG monogram
src/og-image.png            1200x630 social card, made by npm run og
src/fonts/                  Anton and Manrope, woff2
src/images/                 your portrait, 480 and 800 px, jpg and webp
tailwind.config.js, package.json, package-lock.json, .gitignore
scripts/build.mjs           builds dist/ from src/ and the config
scripts/config.mjs          shared config loader and validation
scripts/check.mjs           43 static checks on dist/
scripts/browser-check.mjs   111 browser checks (Playwright and axe)
scripts/make-og.mjs         draws the social card
README.md                   commands, config reference, deploy
HANDOFF.md                  this file
claims-report.txt           the 23 statements to confirm (private, kept out of dist/)
dist/                       the site, ready to upload
screenshots/                six full-page captures from the test run
```

## 5. Removed from the old page

- **Kraken Orderbook**, completely.
- **Invented numbers:** $2M+ funding, 15+ MVPs in 8 weeks, 10M+ requests a month, 99.9% uptime, 300% more organic traffic, 40% drop-off, 90% faster delivery, "Lighthouse 95+", 60% fewer errors, 50K+ onchain interactions, 1000+ updates a second, 70% faster dashboards.
- **Titles:** "Founder & Lead Engineer, Stackweck Studio", "Lead Frontend Architect, Ghonsi Proof 2023 to 2024", "Full Stack Freelance 2021 to 2023, shipped 10+ MVPs".
- **Unsupported claims and tools:** the five-star badge, "Platform Live", Solidity, ethers.js, MetaMask, WalletConnect, The Graph, Figma, Adobe, Sketch, InVision, SEMrush, Ahrefs, AWS, Azure, Docker, Python, MongoDB.
- **Fake furniture:** the studio "we" voice, dead Privacy and Terms links, a contact form that sent nothing, placeholder email and social icons, the marquee ticker, "Profile Img" placeholders.

## 6. SEO summary

- **Title** 53 characters. **Description** 147 characters. One `h1`, headings in order, alt text on the portrait, `lang="en"`.
- **Social tags:** Open Graph and Twitter titles and descriptions always. The social image, canonical link, `og:url` and large-card tag appear only once `siteUrl` is set. A 1200x630 card is already built and waiting.
- **Structured data:** a `Person` record (name, "Lord Gundu", job title, Lagos, Nigeria, the skills on the page, your configured profile links, and Ghonsi Proof as employer, which follows your co-founder statement). A `WebSite` record is added when `siteUrl` is set.
- **robots.txt** is always written and allows crawling. **sitemap.xml** and its robots line appear only when `siteUrl` is set.
- **Not done:** Search Console and Bing submission, backlinks, a custom domain. They need your domain.
- **Performance:** no Lighthouse or PageSpeed score has been measured, so none is claimed. For scale: a visitor downloads about 120 to 145 KB of files before compression (page 50 KB, two fonts 43 KB, one portrait 26 to 49 KB). The social card is not loaded by visitors.

## 7. Configuration you must supply

Edit `site.config.json`, run `npm run build`, upload `dist/`.

| Key | What it unlocks | Note |
| --- | --- | --- |
| `email` | Contact in email mode: the button opens the visitor's mail app | Public once set. Your call. |
| `formEndpoint` (and `formHiddenFields`) | Contact in direct mode: messages reach you without a public address | Never put a secret here. Everything in the file ends up in public HTML. |
| `siteUrl` | Canonical link, social card, sitemap, `WebSite` data | Your real production domain. I did not invent one. |
| `links.linkedin`, `links.x`, `links.medium` | Profile links, Writing links, `sameAs` data | Real URLs only. |
| `links.resume` | "Read my CV" button | A URL where your CV is hosted. |
| `links.perfectFingersLive` | Live link on the Perfect Fingers card | Only if the client agrees. |
| `links.ghonsiProof` | Already `https://ghonsiproof.com` (your word) | I could not reach it. Confirm it. |
| `links.ghonsiRepo` | Repository link in the case study | Only if the repo is public and clean. |
| `links.speakingVirtueRepo`, `authGuardRepo`, `stackweckRepo` | Code links | Empty on purpose until the fixes in section 10. |
| `analytics.plausibleDomain` | Cookie-free analytics | Only if you open a Plausible account. |

You can also set `SITE_URL`, `CONTACT_EMAIL`, `FORM_ENDPOINT` and `PLAUSIBLE_DOMAIN` as environment variables on your host. They override the file.

## 8. Build, lint and test results

Run on 24 November 2026, final state.

- **Build:** passes. Warnings, as expected: `siteUrl` empty, no email or endpoint.
- **Lint:** no ESLint is configured for this project. `npm run check` is the static lint on the output, and `node --check` passes on all five scripts.
- **Static checks:** 43 of 43 pass. They cover: no contractions, none of the removed claims or tools, only the configured email, one `h1`, heading order, unique ids, every anchor and file resolves, no placeholder or CDN links, title and description length, Open Graph and structured data, the social card size, the sitemap and robots rules, and form and analytics rules.
- **Browser checks:** 111 of 111 pass in Chromium at phone (390), tablet (820) and desktop (1440) widths, light and dark: no console errors, no horizontal scroll, fonts loaded, accessibility audit (axe) with zero issues in all six combinations, theme toggle and memory, skip link and focus ring, scroll highlight, phone menu, reduced motion, no-JavaScript view.
- **Contact form (tested against a mock server):** empty, bad email and short message are refused with nothing sent; a real success shows "Message sent" only after the server accepts; a rejected reply, a server error and a dropped connection all say "The message was not sent", keep the visitor's text and offer the fallback email; the honeypot sends nothing; email mode builds a correct mailto link and never claims a send.
- **The checks can fail:** I injected a contraction, a "99.9% uptime" claim, "Kraken" and a dead anchor into a copy of the output, and three checks failed as they should.

## 9. Broken or unverified

- `ghonsiproof.com` could not be opened from my environment. The link and the "Live" label rest on your word.
- The Ghonsi repository refused access. Every detail in "My part" rests on your account, and the block is marked for confirmation.
- The contact form was tested against a mock, not against a live form service. Test once with your real endpoint.
- Email mode: some mail programs cut very long messages.
- Tested in Chromium only. Safari, Firefox and real phones were not tested.
- The social card preview on LinkedIn and X cannot be checked until the site has a public domain.
- No deploy workflow is included. `dist/` is plain files; README lists the build settings for common hosts.
- The VG favicon is new and mine. Replace it if you prefer.

## 10. Additional discoveries (fix before you publish)

1. **Speaking-Virtue tracks `.env` and `backend/.env` in git.** They hold test keys in a public repo. Rotate them, remove the files from history, add `.env` to `.gitignore`. I did not link this repo.
2. **The AuthGuard file contains an email-service (Brevo) API key in public code.** You chose that earlier for the demo, and such keys are often revoked automatically. Confirm it is dead, or revoke it. I did not link this repo, and the card says plainly that it is a front-end demonstration.
3. **The public Stackweck repo still holds the old page with every invented number** (the $2M+ funding, 15+ MVPs, 99.9% uptime, Kraken Orderbook, "Lead Frontend Architect"). Replace its contents with this project or make it private, then set `stackweckRepo`. I left the link empty.
4. **Perfect Fingers ships sample content.** The landing page shows "500+ Happy Clients", "8+ Braid Styles" and "5 star Avg. Rating", plus hard-coded testimonials from named people, team bios and FAQ claims such as "8+ years" and "5+ years". If any of it is not real, replace it before you link the live site or the repo. It sits next to "More than 100 real bookings" on your portfolio. There is also a leftover `TODO.md` from scaffolding.
5. **PotAlert's own About text calls it an offline-capable Progressive Web App.** The code has no service worker and no manifest, and reports live in the browser only. Reword it or add them. The portfolio makes neither claim.
6. Perfect Fingers shows placeholder services if the database returns none. Fine in development; check the live site shows the real ones.

## 11. Facts needing your confirmation

Each id is in `claims-report.txt`. Confirm, then delete the `data-claim` marker in `src/index.html`. If a sentence is not true, change it.

- **Ghonsi Proof:** co-founder title (`ghonsi-cofounder`, `ghonsi-role`; it also feeds the employer line in the structured data); the site is live (`ghonsi-live`); Next.js 15, React 19, Supabase, Express on Render (`ghonsi-stack`); the six "My part" items (`ghonsi-work`); audit of 49 public tables (`ghonsi-49`); Convergence entry in 2026 (`tl-ghonsi-2026`).
- **Client work:** Perfect Fingers and Speaking Virtue are client projects (`pf-client`, `sv-client`); Perfect Fingers replaced a paid scheduling service (`pf-acuity`); more than 100 real bookings (`pf-100`).
- **University projects:** PotAlert and AuthGuard (`pot-noun`, `auth-noun`). Which NOUN project is your final-year project, if any?
- **Writing:** essays and the monthly series (`w-essays`); threads on X (`w-threads`); contests won (`w-contests`) with names and links if you want them named; summary line (`writing-summary`).
- **Client and research names:** NUCOCLOUD, RE.AL, Bitgert, Clave, XCHAINGE, Tech-with-Iroh, Ironside Academy, Ekolance GmbH (`w-clients`, `w-research`).
- **Timeline:** research from 2021 (`tl-research`); Scofield Creativity 2021 to 2023 (`tl-scofield`); freeCodeCamp 2023 (`tl-fcc`); video content 2023 to 2024 (`tl-content`).
- **Not on the page, your call:** FHLU role, Young Gems Initiative (send a two-line description), SIWES at Multigate.io, AbuGem, the Colosseum Frontier listing, faith framing of the essay series.

## 12. Next steps

1. Send me a contact route (an email you are happy to make public, or a form endpoint), your domain, and your X, LinkedIn and Medium URLs. I set them and rebuild.
2. Fix items 1 to 5 in section 10.
3. Confirm or delete the 23 statements.
4. Deploy `dist/`.
